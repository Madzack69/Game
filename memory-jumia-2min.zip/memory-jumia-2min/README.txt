# Memory Jumia — Ultra Simple (≤ 2 minutes, 5 étapes)
- **2 minutes max** pour tout finir : timer global en haut, barre de progression, stages ultra courts.
- **Vouchers par niveau** (1→5), **tap-to-copy** après chaque niveau et **liste finale** avec “Tout copier”.
- **Boutons “Finir maintenant”** (en haut + après un niveau) : termine instantanément et **remets tous les bons**.
- **Lisibilité mobile** : grandes tailles, contraste fort, codes en monospace gras, zones cliquables larges.
- **Aucun asset externe** (très rapide pour trafic élevé).

## Niveaux (très rapides)
1. 2×2 (2 paires)
2. 2×3 (3 paires)
3. 2×4 (4 paires)
4. 3×4 (6 paires)
5. 3×4 (6 paires)

## Hooks (facultatif)
```js
// Soumission (contient vouchers)
MemoryJumia.onSubmit(({ name, email, phone, level, moves, timeMs, vouchers }) => {
  // POST vers votre backend / Sheets
});
```

## Notes
- Le timer démarre à la **première action** et s’arrête à la fin/“Finir maintenant”.
- Si le timer expire, l’app **remet tous les bons automatiquement**.
